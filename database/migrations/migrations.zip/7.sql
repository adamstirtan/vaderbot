UPDATE trivia_questions SET answer = 'new kids on the block' WHERE id = 4
