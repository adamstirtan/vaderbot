UPDATE trivia_questions SET question = "What does the acronym NKOTB stand for?" WHERE id = 4
UPDATE trivia_questions SET question = 'What is the plural of the word crisis?' WHERE id = 7
